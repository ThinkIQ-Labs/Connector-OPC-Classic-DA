#!/bin/bash
#### GENERATED FILE. DO NOT CHECK IN ####
export GIT_COMMIT=10f02feb9459bb54629d5b484d9a4c1c22ca8fad
export GIT_TAG=4.171.3
export GIT_MOST_RECENT_TAG=4.171.3
export GIT_REPO_NAME=thinkiq-dotnet
export GIT_REPO_URL=https://github.com/ThinkIQ/thinkiq-dotnet.git
export BUILD_MACHINE="5b3de5240266"
export BUILD_DATE="2024-03-13 17:31:39"
